/*****************************
 Author: Garrett Fechter
 Purpose: An implementation file for Tile
 Date Created:	4/11/2018
 Modifications: 4/14/2018 Added Display
				4/15/2018 Edited Display to reset console color
******************************/
#include <windows.h>
#include <iostream>
#include "Tile.h"
#define BACKGROUND_GOLD 0x60
#define FOREGROUND_WHITE 0x0F
#define BACKGROUND_BLACK 0x00
/******************************
Method: Tile
Purpose: Default ctor for Tile
Precondition: -
Postcondition: Creates instance of Tile with 0x80 (black on gray)
	and space shape
*******************************/
Tile::Tile() : m_color(0x80), m_shape(' ')
{ }

/******************************
Method: Tile(int color, char shape)
Purpose: Ctor for Tile that takes a color and shape
Precondition: -
Postcondition: Creates instance of Tile with specified color (masked
	only for text color and bg=ackground color bits) and shape
*******************************/
Tile::Tile(int color, char shape) : m_color(color & 0xFF), m_shape(shape)
{ }

/******************************
Method: Tile(const Tile & copy) 
Purpose: Copy constructor for Tile
Precondition: -
Postcondition: Creates a new instance of tile, with shape and color matching
	the copied 
*******************************/
Tile::Tile(const Tile & copy) : m_color(copy.m_color), m_shape(copy.m_shape)
{ }

/******************************
Method: operator=(const Tile & rhs)
Purpose: Assignment operator for Tile
Precondition: Takes an existing instance of Tile
Postcondition: Changes the lhs to have same color/shape as rhs
*******************************/
Tile & Tile::operator=(const Tile & rhs)
{
	m_color = rhs.m_color;
	m_shape = rhs.m_shape;
	return *this;
}
/******************************
Method: ~Tile()
Purpose: Dtor
Precondition: -
Postcondition: Resets all values
*******************************/
Tile::~Tile()
{
	m_color = 0x80;
	m_shape = ' ';
}

/******************************
Method: GetShape() const
Purpose: A getter or m_shape
Precondition: -
Postcondition: Returns m_shape
*******************************/
char Tile::GetShape() const
{
	return m_shape;
}

/******************************
Method: SetShape(char shape)
Purpose: A setter for m_shape
Precondition: Takes a char
Postcondition: Changes m_shape
*******************************/
void Tile::SetShape(char shape)
{
	m_shape = shape;
}

/******************************
Method: GetColor() const
Purpose: A getter for m_color
Precondition: -
Postcondition: returns m_color
*******************************/
int Tile::GetColor() const
{
	return m_color;
}

/******************************
Method: SetColor(int color)
Purpose: A setter for m_color
Precondition: Takes an int
Postcondition: Changes m_color, masking to just the text color & bg bits
*******************************/
void Tile::SetColor(int color)
{
	m_color = color & 0xFF; //mask for last 8 bits
}

/******************************
Method: Display
Purpose: Outputs shape using cout with correct colors
Precondition: -
Postcondition: Outputs a character using cout
*******************************/
void Tile::Display()
{
	HANDLE hStdout = 0;
	hStdout = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(hStdout, m_color & 0xFF);
	std::cout << m_shape;
	SetConsoleTextAttribute(hStdout, FOREGROUND_WHITE | BACKGROUND_BLACK);
}
